
$(document).ready(function() {
    var absoluteHeight = $(".carousel").css("height");
    var bl = document.getElementsByClassName("blankDiv")[0];
    bl.style.height = absoluteHeight;
});